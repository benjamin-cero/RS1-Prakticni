import { Component } from '@angular/core';

@Component({
  selector: 'app-student-semesters-new',
  standalone: false,
  
  templateUrl: './student-semesters-new.component.html',
  styleUrl: './student-semesters-new.component.css'
})
export class StudentSemestersNewComponent {

}
