import { Component } from '@angular/core';

@Component({
  selector: 'app-student-semesters',
  standalone: false,
  
  templateUrl: './student-semesters.component.html',
  styleUrl: './student-semesters.component.css'
})
export class StudentSemestersComponent {

}
