import {Component} from '@angular/core';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrl: './forget-password.component.css',
  standalone: false
})
export class ForgetPasswordComponent {

}
