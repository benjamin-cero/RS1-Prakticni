import {Component} from '@angular/core';

@Component({
  selector: 'app-two-factor',
  templateUrl: './two-factor.component.html',
  styleUrl: './two-factor.component.css',
  standalone: false
})
export class TwoFactorComponent {

}
