﻿namespace RS1_2024_25.API.Data.Enums;

public enum Gender
{
    Male = 1,
    Female = 2,
    Other = 3
}
